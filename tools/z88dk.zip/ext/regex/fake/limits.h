#define	_POSIX2_RE_DUP_MAX	255
#define	CHAR_MIN	(-128)
#define	CHAR_MAX	127
#define	CHAR_BIT	8
