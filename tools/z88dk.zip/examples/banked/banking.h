#ifndef BANKING_H
#define BANKING_H

extern int func_bank1() __banked;
extern int func_bank2() __banked;
extern int func_bank3(int value) __banked;

#endif
