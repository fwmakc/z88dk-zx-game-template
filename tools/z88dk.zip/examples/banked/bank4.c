

#ifndef __SPECTRUM
#pragma bank 4

// This function isn't used, and is just used to push the rom size
// to above 64k so it works in Takeda/MSX
void func_bank4() {

}
#endif
