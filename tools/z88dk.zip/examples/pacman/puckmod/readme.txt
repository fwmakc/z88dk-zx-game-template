This folder should contain the following files:

82s123.7f
82s126.1m
82s126.3m
82s126.4a
pacman.5e
pacman.5f


The following files must exist too, but they will be provided/replaced by z88dk:

namcopac.6e
namcopac.6f
namcopac.6h
npacmod.6j

