#ifndef _READY_SCREEN_H_
#define _READY_SCREEN_H_

void screen_ready_screen_init();
void screen_ready_screen_load();
void screen_ready_screen_update(int *screen_type, int curr_joypad1, int prev_joypad1);

#endif//_READY_SCREEN_H_
