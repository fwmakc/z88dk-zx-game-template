#ifndef _OVER_SCREEN_H_
#define _OVER_SCREEN_H_

#define EXPLOSION		60

void screen_over_screen_init();
void screen_over_screen_load();
void screen_over_screen_update(int *screen_type, int curr_joypad1, int prev_joypad1);

#endif//_OVER_SCREEN_H_
