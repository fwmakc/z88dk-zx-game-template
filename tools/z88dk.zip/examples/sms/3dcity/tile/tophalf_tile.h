#ifndef _TOPHALF_TILE_H_
#define _TOPHALF_TILE_H_

void engine_tile_tophalf_load_tiles(int start, int count);
void engine_tile_tophalf_show_tiles(unsigned char x, unsigned char y, unsigned char width, unsigned char height);

#endif//_TOPHALF_TILE_H_
