/*
 *	Hello World
 */


#include <conio.h>


main()
{
	cprintf("%cHello world!\n",12);
        while(!kbhit()){
        };
        getch();
}
