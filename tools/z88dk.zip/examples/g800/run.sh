#!/bin/sh

g800 -machine=g850 $1 100
